/*
NAMA    : M FAJRIN
NIM     : 1941720010
Kelas   : 1 D
 */
package pertemuan6;
public class Mahasiswa {
String nama;
int thnmasuk,umur;
double ipk;
    Mahasiswa() {
    
    }
    Mahasiswa(String n, int t, int u, double i) {
        nama = n;
        thnmasuk = t;
        umur = u;
        ipk = i;
    }
  
    
     void tampil(){
         System.out.println("\nNama = "+nama);
         System.out.println("Tahun Masuk = "+thnmasuk);
         System.out.println("Umur = "+umur);
         System.out.println("IPK = "+ipk);
     } 
}