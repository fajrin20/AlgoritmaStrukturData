/*
NAMA    : M FAJRIN
NIM     : 1941720010
Kelas   : 1 D
 */
package pertemuan6;
import java.util.Scanner;
public class main {
    public static void main(String[] args) {
        Scanner fajrin=new Scanner(System.in);
        Scanner jrin=new Scanner(System.in);
        DaftarMahasiswaBerprestasi data=new DaftarMahasiswaBerprestasi();
        int jumlMhs=5;
        
        for (int i = 0; i < jumlMhs; i++) {
            System.out.print("\nNama = ");
            String nama= jrin.nextLine();
            System.out.print("Thn masuk = ");
            int thn=fajrin.nextInt();
            System.out.print("Umur = ");
            int umur=fajrin.nextInt();
            System.out.print("IPK = ");
            double ipk=fajrin.nextDouble();
            
            Mahasiswa m= new Mahasiswa(nama,thn,umur,ipk);
            data.tambah(m);
        }
        System.out.println("\nData mahasiswa sebelum sorting = ");
        data.tampil();
        System.out.println("Data mahasiswa setelah disorting decs berdassarkan ipk = ");
        data.bumbleSort();
        data.tampil();
        System.out.println("Data mahasiswa setelah sorting asc berdasarkan ipk = ");
        data.selectionSort();
        data.tampil();
        System.out.println("Data setelah di Insertion sort = ");
        data.InsertionSort(false);
        data.tampil();
    }
}
