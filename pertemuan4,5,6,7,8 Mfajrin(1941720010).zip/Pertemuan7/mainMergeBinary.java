/*
NAMA    : M FAJRIN
NIM     : 1941720010
Kelas   : 1 D
 */
package Pertemuan7;

import java.util.Scanner;
public class mainMergeBinary {
     public static void main(String[] args) {
        Scanner fajrin=new Scanner(System.in);
        int[] a = new int[8];
        for (int i = 0; i < a.length; i++){
            System.out.print("Data ke-"+(i+1)+" = ");
            int input=fajrin.nextInt();
            a[i] = input;
        }
        Merge_sort sms=new Merge_sort();
        System.out.println("<<<Sorting dengan Merge Sort>>>");
        System.out.println("-------------Data Awal----------------");
        sms.printArray(a);
        sms.mergeSort(a);
        System.out.println("--------Data Setelah Diurutkan--------");
        sms.printArray(a);
        
        System.out.print("Masukkan data yang ingin di cari\t: ");
        int nilai=fajrin.nextInt();
        
        binary b=new binary(a,8);
        System.out.println("<<<<<<<<Binary Search>>>>>>>>");
        int posisi=b.FindBinarySearch(nilai,0,a.length-1);
        b.TampilPosisi(nilai, posisi);
    }
}
