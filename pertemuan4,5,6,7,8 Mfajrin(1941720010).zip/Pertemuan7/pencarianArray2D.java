/*
NAMA    : M FAJRIN
NIM     : 1941720010
Kelas   : 1 D
 */
package Pertemuan7;
import java.util.Scanner;
            
public class pencarianArray2D {
    
    public static void main(String[] args) {
    Scanner fajrin = new Scanner(System.in);
    
      System.out.print("Masukan baris : ");
      int baris = fajrin.nextInt();
      System.out.print("Masukan kolom : ");
      int kolom = fajrin.nextInt();
      int[][] matriks = new int[baris][kolom];

        System.out.println("");
        for(int x=0; x<baris;x++){
        for(int y=0; y<kolom;y++){
        System.out.print("matriks["+(x+1)+"]["+(y+1)+"] : ");
        matriks[x][y]=fajrin.nextInt();
        }
    }
        System.out.println();
        System.out.println("Bentuk matriks:");
        for (int i = 0; i < baris; i++) {
            for (int j = 0; j < kolom; j++) {
                System.out.print(matriks[i][j]+" ");
            }
            System.out.println();
        }

        System.out.print("Masukan nilai yang dicari : ");
        int cari = fajrin.nextInt();

        SequentialSearch ss=new SequentialSearch(matriks,baris,kolom);
        System.out.println("<<<Pencarian menggunakan Sequential Sort");
        ss.FindSeqSearch(cari);
   }
   
}