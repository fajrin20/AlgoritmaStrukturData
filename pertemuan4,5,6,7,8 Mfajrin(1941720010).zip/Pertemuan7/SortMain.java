/*
NAMA    : M FAJRIN
NIM     : 1941720010
Kelas   : 1 D
 */
package Pertemuan7;
public class SortMain {
    public static void main(String[] args) {
        int data[]={10,40,30,50,70,20,100,90};
        System.out.println("sorting dengan merge sort");
        MergeSorting mSort=new MergeSorting();
        System.out.println("Data Awal");
        mSort.printArray(data);
        mSort.mergeSort(data);
        System.out.println("Setelah diurutkan");
        mSort.printArray(data);
    }
}
