/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/*
NAMA    : M FAJRIN
NIM     : 1941720010
Kelas   : 1 D
 *//
public class maxMin {
     public int maximum,minimum;
}